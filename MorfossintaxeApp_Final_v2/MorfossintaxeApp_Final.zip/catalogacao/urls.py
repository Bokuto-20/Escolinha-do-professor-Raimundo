from django.urls import path
from . import views, views_pln

urlpatterns = [
    path('', views.periodo_list, name='periodo_list'),
    path('periodo/<int:pk>/', views.periodo_detail, name='periodo_detail'),
    path('analise-automatica/', views_pln.analise_automatica, name='analise_automatica'),
]
